﻿<?php

class Header{
	
	public function run(){
		return Html::load('header.html');
	}

}
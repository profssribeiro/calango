﻿<?php

class Footer{
	
	public function run(){
		return Html::load('footer.html');
	}

}
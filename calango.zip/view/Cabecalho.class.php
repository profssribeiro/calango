﻿<?php

class Cabecalho{
	
	public function run(){
		return Html::load('cabecalho.html');
	}

}
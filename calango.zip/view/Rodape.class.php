﻿<?php

class Rodape{
	
	public function run(){
		return Html::load('rodape.html');
	}

}